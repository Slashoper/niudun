package com.example.hive.udf;
import org.apache.hadoop.hive.ql.exec.UDF;
import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;
import java.net.URL;

public final class Tld1 extends UDF {
	public static List<String> lst = new ArrayList<String>();
	static {  
		lst.add(".com.cn");
		lst.add(".net.cn");
		lst.add(".org.cn");
		lst.add(".gov.cn");
		lst.add(".edu.cn");
		lst.add(".com");
		lst.add(".co");
		lst.add(".net");
		lst.add(".org");
		lst.add(".cn");
		lst.add(".me");
		lst.add(".biz");
                lst.add(".vc");
                lst.add(".js.cn");
                lst.add(".top");
		lst.add(".name");
		lst.add(".info");
		lst.add(".me");
		lst.add(".so");
                lst.add(".club");
		lst.add(".tel");
                lst.add(".xyz");
                lst.add(".mil.cn");
                lst.add(".ln.cn");
		lst.add(".mobi");
                lst.add(".wang");
                lst.add(".vg");
		lst.add(".asia");
                lst.add(".hk");
                lst.add(".dk");
                lst.add(".es");
                lst.add(".ro");
                lst.add(".ga");
                lst.add(".gd");
                lst.add(".in");
                lst.add(".ml");
		lst.add(".cc");
                lst.add(".la");
		lst.add(".io");
		lst.add(".im");
		lst.add(".pw");
                lst.add(".us");
                lst.add(".tt");
                lst.add(".pro");
                lst.add(".li");
		lst.add(".tv");
		lst.add(".science");
    };  

	public String evaluate(final String url, final String txt) {
		try{
			URL ret = new URL(url);
			return this.getTld(ret.getHost());
		}catch(Exception e){
			return url;
		}
	}

	public String evaluate(final String tid) {
		return this.getTld(tid);
	}

	public String getTld(final String tid) {
		try{
			String x = tid;
			Iterator<String> iterator = Tld1.lst.iterator();
			while (iterator.hasNext())
			{
				String tld = (String)iterator.next();
				if(x.endsWith(tld)){
					String substr = x.substring(0, x.length()-tld.length());
					String ret = x.substring(substr.lastIndexOf(".")+1);
					return ret;
				}
			}
			return tid;
		}catch(Exception e){
			return tid;
		}
	}
}
